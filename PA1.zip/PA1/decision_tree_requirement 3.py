#implementation of Decision tree from Scikit learn and comparison with the own ID3 algorithm.




import numpy as np
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from mlxtend.plotting import plot_confusion_matrix
from sklearn import tree
import graphviz
import matplotlib.pyplot as plt
from graphviz import Source


def confusionMatrixCalculation(ypred,ytest):
    
    y_pred=np.asarray(ypred)
    y_test=np.asarray(ytest)
    
    #finding the True Positive
    t_p = np.sum(np.logical_and(y_pred == 1 , y_test == 1))
    
    #finding the True Negative
    t_n = np.sum(np.logical_and(y_pred == 0, y_test == 0))
    
    #finding the false positive
    f_p = np.sum(np.logical_and(y_pred == 1, y_test == 0))
    
    #finding the false negative
    f_n = np.sum(np.logical_and(y_pred == 0, y_test == 1))
    
    binary1 = np.array([[t_p,f_n],[f_p,t_n]])
    
    fig, ax = plot_confusion_matrix(conf_mat=binary1,show_absolute=True,
                                show_normed=True,
                                colorbar=True)
    plt.show()
    
    return [[t_p,f_n],[f_p,t_n]]
 


M = np.genfromtxt('./data/monks-1.train', missing_values=0, skip_header=0, delimiter=',', dtype=int)
#ytrn = M[:, 0]
#Xtrn = M[:, 1:]

X_train=pd.DataFrame(M)
X_train.columns=['label','col1','col2','col3','col4','col5','col6']

Y_train=X_train['label']
X_train=X_train.drop('label',axis=1)

# Load the test data
M = np.genfromtxt('./data/monks-1.test', missing_values=0, skip_header=0, delimiter=',', dtype=int)

X_test = pd.DataFrame(M)
X_test.columns=['label','col1','col2','col3','col4','col5','col6']

Y_test = X_test['label']
X_test = X_test.drop('label',axis=1)

classifier_model = DecisionTreeClassifier()
classifier_model.fit(X_train,Y_train)

dot_data = tree.export_graphviz(classifier_model, 
                  feature_names=X_train.columns,  
                  class_names=["True","False"],  
                  filled=True, rounded=True,  
                  special_characters=True,
                   out_file=None,
                           )

graph = graphviz.Source(dot_data)
graph = Source( tree.export_graphviz(classifier_model, out_file=None, feature_names=X_train.columns))
graph.format = 'png'

graph.view()

Y_predicted = classifier_model.predict(X_test)

print("Confusion Matrix for the model learnt by ScikitLearn DecisionTree")

cf_matrix=confusionMatrixCalculation(Y_test,Y_predicted)
print("open the image generated to visualize the DT generated")








