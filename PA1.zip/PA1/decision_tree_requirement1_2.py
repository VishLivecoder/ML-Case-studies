# decision_tree.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# personal and educational purposes provided that (1) you do not distribute
# or publish solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UT Dallas, including a link to http://cs.utdallas.edu.
#
# This file is part of Programming Assignment 1 for CS6375: Machine Learning.
# Gautam Kunapuli (gautam.kunapuli@utdallas.edu)
# Sriraam Natarajan (sriraam.natarajan@utdallas.edu),
#
#
# INSTRUCTIONS:
# ------------
# 1. This file contains a skeleton for implementing the ID3 algorithm for
# Decision Trees. Insert your code into the various functions that have the
# comment "INSERT YOUR CODE HERE".
#
# 2. Do NOT modify the classes or functions that have the comment "DO NOT
# MODIFY THIS FUNCTION".
#
# 3. Do not modify the function headers for ANY of the functions.
#
# 4. You may add any other helper functions you feel you may need to print,
# visualize, test, or save the data and results. However, you MAY NOT utilize
# the package scikit-learn OR ANY OTHER machine learning package in THIS file.

import numpy as np
import math
import matplotlib.pyplot as plt
from mlxtend.plotting import plot_confusion_matrix


def partition(x):
    """
    Partition the column vector x into subsets indexed by its unique values (v1, ... vk)

    Returns a dictionary of the form
    { v1: indices of x == v1,
      v2: indices of x == v2,
      ...
      vk: indices of x == vk }, where [v1, ... vk] are all the unique values in the vector z.
    """

    # INSERT YOUR CODE HERE
    
    column_vector={}
    for value in np.unique(x):
        column_vector.update({value:(x==value).nonzero()[0]})
    
    return column_vector
    raise Exception('Function not yet implemented!')


def entropy(y):
    """
    Compute the entropy of a vector y by considering the counts of the unique values (v1, ... vk), in z

    Returns the entropy of z: H(z) = p(z=v1) log2(p(z=v1)) + ... + p(z=vk) log2(p(z=vk))
    """

    # INSERT YOUR CODE HERE
    values,counts=np.unique(y,return_counts=True)
    entropy_h=0
    
    for i in range(len(values)):
        probability=counts[i]/len(y)
        entropy_h-=probability*math.log2(probability)
        
    return entropy_h

    raise Exception('Function not yet implemented!')


def mutual_information(x, y):
    """
    Compute the mutual information between a data column (x) and the labels (y). The data column is a single attribute
    over all the examples (n x 1). Mutual information is the difference between the entropy BEFORE the split set, and
    the weighted-average entropy of EACH possible split.

    Returns the mutual information: I(x, y) = H(y) - H(y | x)
    """

    # INSERT YOUR CODE HERE
    
    entropy_y=entropy(y)
    x_vals , counts = np.unique(x,return_counts=True)
    
    px = counts/len(x)
    
    mapped = zip(px,x_vals)
    
    #weighted-average entropy of each possible split
    for probability,value in mapped:
        entropy_y-=probability*entropy(y[x==value]) 
        
    return entropy_y
    
    raise Exception('Function not yet implemented!')


def id3(x, y, attribute_value_pairs=None, depth=0, max_depth=5):
    """
    Implements the classical ID3 algorithm given training data (x), training labels (y) and an array of
    attribute-value pairs to consider. This is a recursive algorithm that depends on three termination conditions
        1. If the entire set of labels (y) is pure (all y = only 0 or only 1), then return that label
        2. If the set of attribute-value pairs is empty (there is nothing to split on), then return the most common
           value of y (majority label)
        3. If the max_depth is reached (pre-pruning bias), then return the most common value of y (majority label)
    Otherwise the algorithm selects the next best attribute-value pair using INFORMATION GAIN as the splitting criterion
    and partitions the data set based on the values of that attribute before the next recursive call to ID3.

    The tree we learn is a BINARY tree, which means that every node has only two branches. The splitting criterion has
    to be chosen from among all possible attribute-value pairs. That is, for a problem with two features/attributes x1
    (taking values a, b, c) and x2 (taking values d, e), the initial attribute value pair list is a list of all pairs of
    attributes with their corresponding values:
    [(x1, a),
     (x1, b),
     (x1, c),
     (x2, d),
     (x2, e)]
     If we select (x2, d) as the best attribute-value pair, then the new decision node becomes: [ (x2 == d)? ] and
     the attribute-value pair (x2, d) is removed from the list of attribute_value_pairs.

    The tree is stored as a nested dictionary, where each entry is of the form
                    (attribute_index, attribute_value, True/False): subtree
    * The (attribute_index, attribute_value) determines the splitting criterion of the current node. For example, (4, 2)
    indicates that we test if (x4 == 2) at the current node.
    * The subtree itself can be nested dictionary, or a single label (leaf node).
    * Leaf nodes are (majority) class labels

    Returns a decision tree represented as a nested dictionary, for example
    {(4, 1, False):
        {(0, 1, False):
            {(1, 1, False): 1,
             (1, 1, True): 0},
         (0, 1, True):
            {(1, 1, False): 0,
             (1, 1, True): 1}},
     (4, 1, True): 1}
    """

    # INSERT YOUR CODE HERE. NOTE: THIS IS A RECURSIVE FUNCTION.
    tree={}
    if  attribute_value_pairs is None:
        attribute_value_pairs=np.vstack([[(column, unique_value) for unique_value in np.unique(x[:, column])] for column in range(x.shape[1])])
    
    y_values , y_counts = np.unique(y,return_counts=True)
    
    #1st terminal condition
    if len(y_values) == 1:
        return y_values[0]
    
    #2nd and 3rd Terminal Condition
    if len(attribute_value_pairs) == 0 or depth == max_depth:
        return y_values[np.argmax(y_counts)]
    
    m_i = np.array([mutual_information(np.array(x[:,attribute] == attribute_value).astype(int), y)
                            for (attribute,attribute_value) in attribute_value_pairs])
    
    
    (attribute,attribute_value) =attribute_value_pairs[np.argmax(m_i)]
    
    partitions = partition(np.array(x[:,attribute] == attribute_value).astype(int))
    
    attribute_value_pairs = np.delete(attribute_value_pairs, np.argwhere(np.all(attribute_value_pairs == (attribute, attribute_value), axis=1)), 0)
    

    for s_v, indices in partitions.items():
        x_subset = x.take(indices, axis=0)
        y_subset = y.take(indices, axis=0)
        decision = bool(s_v)
        
        tree[(attribute, attribute_value, decision)] = id3(x_subset, y_subset, attribute_value_pairs=attribute_value_pairs,
                                            max_depth=max_depth, depth=depth + 1)
        
    return tree
    
    raise Exception('Function not yet implemented!')


def predict_example(x, tree):
    """
    Predicts the classification label for a single example x using tree by recursively descending the tree until
    a label/leaf node is reached.

    Returns the predicted label of x according to tree
    """

    # INSERT YOUR CODE HERE. NOTE: THIS IS A RECURSIVE FUNCTION.
    for split_criterion , sub_trees in tree.items():
        attribute_index = split_criterion[0]
        attribute_value = split_criterion[1]
        split_decision = split_criterion[2]
        
        if split_decision == (x[attribute_index] == attribute_value):
            if type(sub_trees) is dict:
                label = predict_example(x, sub_trees)
            else:
                label=sub_trees
            
            return label 
    
    
    
    
    
    raise Exception('Function not yet implemented!')


def compute_error(y_true, y_pred):
    """
    Computes the average error between the true labels (y_true) and the predicted labels (y_pred)

    Returns the error = (1/n) * sum(y_true != y_pred)
    """

    # INSERT YOUR CODE HERE
    n=len(y_true)
    error=[ y_true[index]!= y_pred[index] for index in range(n)]
    return sum(error)/n
   
    raise Exception('Function not yet implemented!')
    

def confusionMatrixCalculation(ypred,ytest):
    
    y_pred=np.asarray(ypred)
    y_test=np.asarray(ytest)
    
    #finding the True Positive
    t_p = np.sum(np.logical_and(y_pred == 1 , y_test == 1))
    
    #finding the True Negative
    t_n = np.sum(np.logical_and(y_pred == 0, y_test == 0))
    
    #finding the false positive
    f_p = np.sum(np.logical_and(y_pred == 1, y_test == 0))
    
    #finding the false negative
    f_n = np.sum(np.logical_and(y_pred == 0, y_test == 1))
    
    binary1 = np.array([[t_p,f_n],[f_p,t_n]])
    
    fig, ax = plot_confusion_matrix(conf_mat=binary1,show_absolute=True,
                                show_normed=True,
                                colorbar=True)
    plt.show()
    
    
    
    
    
    return [[t_p,f_n],[f_p,t_n]]
 


def visualize(tree, depth=0):
    """
    Pretty prints (kinda ugly, but hey, it's better than nothing) the decision tree to the console. Use print(tree) to
    print the raw nested dictionary representation.
    DO NOT MODIFY THIS FUNCTION!
    """

    if depth == 0:
        print('TREE')

    for index, split_criterion in enumerate(tree):
        sub_trees = tree[split_criterion]

        # Print the current node: split criterion
        print('|\t' * depth, end='')
        print('+-- [SPLIT: x{0} = {1}]'.format(split_criterion[0], split_criterion[1]))

        # Print the children
        if type(sub_trees) is dict:
            visualize(sub_trees, depth + 1)
        else:
            print('|\t' * (depth + 1), end='')
            print('+-- [LABEL = {0}]'.format(sub_trees))


if __name__ == '__main__':
   
    
    # Load the training data
    
    for datasetNumber in range(1,4):
        
        test_error_list=[]
        depth_list=[]
        training_error_list=[]
        
        #declaring list in order to collect all the datas for each dataset
        
       
        M = np.genfromtxt('./data/monks-'+str(datasetNumber)+'.train', missing_values=0, skip_header=0, delimiter=',', dtype=int)
        ytrn = M[:, 0]
        Xtrn = M[:, 1:]
        # Load the test data
        M = np.genfromtxt('./data/monks-'+str(datasetNumber)+'.test', missing_values=0, skip_header=0, delimiter=',', dtype=int)
        ytst = M[:, 0]
        Xtst = M[:, 1:]
        
        for tree_depth in range(1,11):
        # Learn a decision tree of depth 1-11
        
        
            
            depth_list.append(tree_depth)
            #implementation of ID3 Algorithm
            decision_tree = id3(Xtrn, ytrn, max_depth=tree_depth)
            
            
            # Compute the test error
            y_predicted = [predict_example(x, decision_tree) for x in Xtst]
            tst_err = compute_error(ytst, y_predicted)
            
            
            
            #finding the confusion matrix for monks1 and tree depth 1 and 2 to meet requirement b
            if datasetNumber == 1:
                
                if tree_depth == 1:
                    print("Meeting requirement 2")
                    print("Decision Tree of Level "+str(tree_depth))
                    visualize(decision_tree)
                    cf_matrix=confusionMatrixCalculation(y_predicted, ytst)
                if tree_depth == 2:
                    print("Meeting requirement 2")
                    print("Decision Tree of Level "+str(tree_depth))
                    visualize(decision_tree)
                    cf_matrix=confusionMatrixCalculation(y_predicted, ytst)    
                    
                
                   
            
            
            
           

          
            
            
            
            
  
            
            
           
            
            
            #computing the training error 
            y_training_predicted= [predict_example(x,decision_tree) for x in Xtrn]
            training_error=compute_error(y_training_predicted,ytrn)
            
             
             
            training_error_list.append(training_error)
            test_error_list.append(tst_err)
            
            
        print("train and test error plot for monks-"+str(datasetNumber))
        fig,ax=plt.subplots()
        plt.xlabel('depth of tree')
        plt.ylabel(' error')
        plt.plot(depth_list,training_error_list,'r',label='training error')
        plt.plot(depth_list, test_error_list,'b',label='test error')
        legend = ax.legend(loc='upper center', shadow=True, fontsize='x-large')
        plt.savefig('monks__'+ str(datasetNumber)+ '.png')
        plt.show()   
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
