#Implementing the Decision tree classifier on the Tic-Tac-Toe dataset.

            

import numpy as np
import pandas as pd
#import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier

from sklearn import tree,preprocessing
import graphviz
from graphviz import Source
import decision_tree_requirement1_2


#considering a TIC-TAC-TOE Dataset from UCI Repository
M = np.genfromtxt('./data/tic-tac-toe.data', missing_values=0, skip_header=0, delimiter=',', dtype=str)
dataset=pd.DataFrame(M)
dataset.columns=["Top_Left","Top_Middle","Top_Right","Middle_Left","Middle_Middle","Middle_Right","Bottom_Left","Bottom_Middle","Bottom_Right","class"]

# label_encoder object knows how to understand word labels. 
label_encoder=preprocessing.LabelEncoder()

#label encoding each column
for column in dataset.columns:
    dataset[column] = label_encoder.fit_transform(dataset[column])
        
X = dataset.drop('class', axis=1)
y = dataset['class']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20)

Xtrn=np.asarray(X_train)
Xtst=np.asarray(X_test)

Ytrn=np.asarray(y_train)
Ytst=np.asarray(y_test)


#This is the Decision tree that is self implemented(ID3 algorithm)
decision_tree=decision_tree_requirement1_2.id3(Xtrn,Ytrn,max_depth=5)
y_pred = [decision_tree_requirement1_2.predict_example(x, decision_tree) for x in Xtst]


#this is the Decision tree from Scikit learn
classifier_model = DecisionTreeClassifier()
classifier_model.fit(X_train, y_train)


print("Confusion Matrix for Manual Decision Tree is:\n")
print(decision_tree_requirement1_2.confusionMatrixCalculation(y_pred,Ytst))


y_pred = classifier_model.predict(X_test)
print("Confusion Matrix for Scikitlearn Decision tree is\n")
print(decision_tree_requirement1_2.confusionMatrixCalculation(y_test, y_pred))

dot_data = tree.export_graphviz(classifier_model, 
                  feature_names=X_train.columns,  
                  class_names=["True","False"],  
                  filled=True, rounded=True,  
                  special_characters=True,
                   out_file=None,
                           )

graph = graphviz.Source(dot_data)
graph = Source( tree.export_graphviz(classifier_model, out_file=None, feature_names=X_train.columns))
graph.format = 'png'

graph.view()
print("open the image generated to visualize the DT generated")

