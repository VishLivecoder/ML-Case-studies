# decision_tree.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# personal and educational purposes provided that (1) you do not distribute
# or publish solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UT Dallas, including a link to http://cs.utdallas.edu.
#
# This file is part of Programming Assignment 1 for CS6375: Machine Learning.
# Gautam Kunapuli (gautam.kunapuli@utdallas.edu)
# Sriraam Natarajan (sriraam.natarajan@utdallas.edu),
#
#
# INSTRUCTIONS:
# ------------
# 1. This file contains a skeleton for implementing the ID3 algorithm for
# Decision Trees. Insert your code into the various functions that have the
# comment "INSERT YOUR CODE HERE".
#
# 2. Do NOT modify the classes or functions that have the comment "DO NOT
# MODIFY THIS FUNCTION".
#
# 3. Do not modify the function headers for ANY of the functions.
#
# 4. You may add any other helper functions you feel you may need to print,
# visualize, test, or save the data and results. However, you MAY NOT utilize
# the package scikit-learn OR ANY OTHER machine learning package in THIS file.

import numpy as np

import matplotlib.pyplot as plt
from mlxtend.plotting import plot_confusion_matrix
import pandas as pd
from random import randrange
from sklearn import preprocessing
from sklearn.ensemble import BaggingClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import AdaBoostClassifier


def partition(x):
    """
    Partition the column vector x into subsets indexed by its unique values (v1, ... vk)

    Returns a dictionary of the form
    { v1: indices of x == v1,
      v2: indices of x == v2,
      ...
      vk: indices of x == vk }, where [v1, ... vk] are all the unique values in the vector z.
    """

    # INSERT YOUR CODE HERE
    
    column_vector={}
    for value in np.unique(x):
        column_vector.update({value:(x==value).nonzero()[0]})
    
    return column_vector
    raise Exception('Function not yet implemented!')


def entropy(y, sample_weights=None):
    """
    Compute the entropy of a vector y by considering the counts of the unique values (v1, ... vk), in z
    Returns the entropy of z: H(z) = p(z=v1) log2(p(z=v1)) + ... + p(z=vk) log2(p(z=vk))
    """

    # INSERT YOUR CODE HERE
    unique_values = partition(y)
    number_of_samples = len(y)
    hy = 0
    for elem in unique_values.keys():
        if sample_weights is None:
            p_elem = (float) (len(unique_values[elem]) / number_of_samples)
        else:
            p_elem = 0
            for idx in unique_values[elem]:
                p_elem += sample_weights[idx]

        log_p_elem = np.log2(p_elem)
        hy += -(p_elem * log_p_elem)
    return hy
    # raise Exception('Function not yet implemented!')


def mutual_information(x, y, sample_weights=None):
    """
    Compute the mutual information between a data column (x) and the labels (y). The data column is a single attribute
    over all the examples (n x 1). Mutual information is the difference between the entropy BEFORE the split set, and
    the weighted-average entropy of EACH possible split.
    Returns the mutual information: I(x, y) = H(y) - H(y | x)
    """

    # INSERT YOUR CODE HERE
    hy = entropy(y, sample_weights)
    unique_values_of_x = partition(x)
    number_of_samples = len(x)
    hyx = 0
    for elem in unique_values_of_x.keys():
        if sample_weights is None:
            p_x_elem = (float) (len(unique_values_of_x[elem]) / number_of_samples)
            sample_weights_new = None
        else:
            p_x_elem = 0
            for idx in unique_values_of_x[elem]:
                p_x_elem += sample_weights[idx]
            sample_weights_new = [sample_weights[i] for i in unique_values_of_x[elem]]
        y_new = [y[i] for i in unique_values_of_x[elem]]
        hyx_elem = entropy(y_new, sample_weights_new)
        hyx += (p_x_elem * hyx_elem)
    return (hy - hyx)
    # raise Exception('Function not yet implemented!')


def id3(x, y, attribute_value_pairs=None, depth=0, max_depth=5, sample_weights=None):
 
    dtree = {}

    if attribute_value_pairs is None:
        attribute_value_pairs = []
        
        for idx in range (len(x[0])):
            for val in np.unique(np.array([item[idx] for item in x])):
                attribute_value_pairs.append((idx, val))

    attribute_value_pairs = np.array(attribute_value_pairs)

    # check for pure splits
    unique_values_of_y, count_y = np.unique(y, return_counts=True)
    if len(unique_values_of_y) == 1:
        return unique_values_of_y[0]

    if len(attribute_value_pairs) == 0 or depth == max_depth:
        return unique_values_of_y[np.argmax(count_y)]

    info_gain = []

    for feat, val in attribute_value_pairs:
        info_gain.append(mutual_information(np.array((x[:, feat] == val).astype(int)), y, sample_weights))

    info_gain = np.array(info_gain)
    (feat, val) = attribute_value_pairs[np.argmax(info_gain)]

    partitions = partition(np.array((x[:, feat] == val).astype(int)))

    attribute_value_pairs = np.delete(attribute_value_pairs, np.argmax(info_gain), 0)

    for value, indices in partitions.items():
        x_new = x.take(np.array(indices), axis=0)
        y_new = y.take(np.array(indices), axis=0)
        output = bool(value)
        if sample_weights is None:
            dtree[(feat, val, output)] = id3(x_new, y_new, attribute_value_pairs=attribute_value_pairs, depth=depth+1, max_depth=max_depth)
        else:
            sample_weights_new = sample_weights.take(np.array(indices), axis=0)
            dtree[(feat, val, output)] = id3(x_new, y_new, attribute_value_pairs=attribute_value_pairs, depth=depth+1, max_depth=max_depth, sample_weights=sample_weights_new)

    return dtree

def predict_example(x, tree):
    """
    Predicts the classification label for a single example x using tree by recursively descending the tree until
    a label/leaf node is reached.

    Returns the predicted label of x according to tree
    """

    # INSERT YOUR CODE HERE. NOTE: THIS IS A RECURSIVE FUNCTION.
    for split_criterion , sub_trees in tree.items():
        attribute_index = split_criterion[0]
        attribute_value = split_criterion[1]
        split_decision = split_criterion[2]
        
        
        if split_decision == (x[attribute_index] == attribute_value):
            if type(sub_trees) is dict:
                label = predict_example(x, sub_trees)
            else:
                label=sub_trees
            
            return label 
    
    
    
    
    
    raise Exception('Function not yet implemented!')


def compute_error(y_true, y_pred):
    """
    Computes the average error between the true labels (y_true) and the predicted labels (y_pred)

    Returns the error = (1/n) * sum(y_true != y_pred)
    """

    # INSERT YOUR CODE HERE
    n=len(y_true)
    error=[ y_true[index]!= y_pred[index] for index in range(n)]
    return sum(error)/n
   
    raise Exception('Function not yet implemented!')
    

def confusionMatrixCalculation(ypred,ytest):
    
    y_pred=np.asarray(ypred)
    y_test=np.asarray(ytest)
    
    #finding the True Positive
    t_p = np.sum(np.logical_and(y_pred == 1 , y_test == 1))
    
    #finding the True Negative
    t_n = np.sum(np.logical_and(y_pred == 0, y_test == 0))
    
    #finding the false positive
    f_p = np.sum(np.logical_and(y_pred == 1, y_test == 0))
    
    #finding the false negative
    f_n = np.sum(np.logical_and(y_pred == 0, y_test == 1))
    
    binary1 = np.array([[t_p,f_n],[f_p,t_n]])
    
    fig, ax = plot_confusion_matrix(conf_mat=binary1,show_absolute=True,
                                show_normed=True,
                                colorbar=True)
    plt.show()
    
    
    
    
    
    return [[t_p,f_n],[f_p,t_n]]
 


def visualize(tree, depth=0):
    """
    Pretty prints (kinda ugly, but hey, it's better than nothing) the decision tree to the console. Use print(tree) to
    print the raw nested dictionary representation.
    DO NOT MODIFY THIS FUNCTION!
    """

    if depth == 0:
        print('TREE')

    for index, split_criterion in enumerate(tree):
        sub_trees = tree[split_criterion]

        # Print the current node: split criterion
        print('|\t' * depth, end='')
        print('+-- [SPLIT: x{0} = {1}]'.format(split_criterion[0], split_criterion[1]))

        # Print the children
        if type(sub_trees) is dict:
            visualize(sub_trees, depth + 1)
        else:
            print('|\t' * (depth + 1), end='')
            print('+-- [LABEL = {0}]'.format(sub_trees))

            



# Create a random subsample from the dataset with replacement
def subsample(dataset_train, ratio=0.65):
	sample = list()
	n_sample = round(len(dataset) * ratio)
	while len(sample) < n_sample:
		index = randrange(len(dataset_train))
		sample.append(dataset_train.iloc[index])
	return sample






def predict_example_1(dataset_test,DTS):
    y_pred=[]
    Xtest=dataset_test.drop("y",axis=1)
    Ytest=dataset_test["y"]
    Xtest=Xtest.to_numpy()
    Ytest=Ytest.to_numpy()
   
    for x in Xtest :
        for DT in DTS:
                 
            prediction=[predict_example(x,DT)]
        y_pred.append(max(set(prediction), key=prediction.count))
    #print(y_pred)
    #print(Ytest)
    confusionMatrixCalculation(y_pred,Ytest)
    
def bagging(dataset_train,dataset_test,sample_size,n_trees,maxd):
    DTS=list()
    for i in range(n_trees):
        sample=subsample(dataset_train,sample_size)
        sample=pd.DataFrame(sample)
        Xtrn=sample.drop("y",axis=1)
        Ytrn=sample["y"]
        Xtrn=Xtrn.to_numpy()
        Ytrn=Ytrn.to_numpy()
        DT=id3(Xtrn,Ytrn,max_depth=maxd)
        DTS.append(DT)
    predict_example_1(dataset_test,DTS)
    
    
    
def boosting(x, y, max_depth, num_stumps):
    h_ensemble = []
    n_s = x.shape[0]
    w_l = np.ones(y.shape)
    w_l /= n_s
    for i in range(num_stumps):
       
        h_l = id3(x, y, max_depth=max_depth, sample_weights=w_l)
        y_pred = [predict_example(sample, h_l) for sample in x]
        eps_t = np.dot(np.absolute(y - y_pred), w_l)
        
        alpha = 0.5 * np.log(((1 - eps_t) / eps_t))
        
        indicator = np.absolute(y - y_pred)
        for i_x, w in enumerate(w_l):
            if indicator[i_x]:
                w_l[i_x] *= np.exp(alpha)
            else:
                w_l[i_x] *= np.exp(-alpha)
        w_l /= 2 * np.sqrt(eps_t * (1 - eps_t))
        h_ensemble.append((alpha, h_l))
    return h_ensemble

def predict_example_ensembles(x, h_ens):
    y_pred = sum([predict_example(x, h_l[1]) * h_l[0] for h_l in h_ens])
    y_pred /= sum([h_l[0] for h_l in h_ens])
    if y_pred>0.5:
        y_pred = 1
    else:
        y_pred = 0
    return y_pred
    
    
        
#read the csv file
data_full=pd.read_csv("./data/mushroom.csv");




# label_encoder object knows how to understand word labels. 
label_encoder=preprocessing.LabelEncoder()

#label encoding each column
for column in data_full.columns:
    data_full[column] = label_encoder.fit_transform(data_full[column])

#dropping the y label from the set of features and seperating it.

dataset=pd.DataFrame(data_full);
dataset_x=dataset.drop(labels="y",axis=1);

dataset_y=dataset["y"]
dataset_train=dataset[0:4000]
dataset_test=dataset[4000:4875]






    
    
    



print("Confusion matrix for Bagging- Own Implementation")   
        
print("max_depth="+"3"+"Number of estimators="+"10")    
bagging(dataset_train,dataset_test,0.65,10,3)
print("max_depth="+"3"+"Number of estimators="+"20") 

bagging(dataset_train,dataset_test,0.65,20,3)
print("max_depth="+"5"+"Number of estimators="+"10") 
bagging(dataset_train,dataset_test,0.65,10,5)
print("max_depth="+"5"+"Number of estimators="+"20") 
bagging(dataset_train,dataset_test,0.65,20,5)





Xtrn=dataset_train.drop("y",axis=1)
ytrn=dataset_train["y"]
Xtest=dataset_test.drop("y",axis=1)
Ytest=dataset_test["y"]
Xtest=Xtest.to_numpy()
Ytest=Ytest.to_numpy()
Xtrn=Xtrn.to_numpy()
ytrn=ytrn.to_numpy()

print("Confusion matrix for Adaboost -Own Implementation")
for depth in [1, 2]:
    for stump in [20, 40]:
        

        
        h_ens_boost = boosting(Xtrn, ytrn, max_depth=depth, num_stumps=stump)
        y_pred_ens_boost = [predict_example_ensembles(x, h_ens_boost) for x in Xtest]
        tst_err_ens_boost = compute_error(Ytest, y_pred_ens_boost)
        print("max_depth="+str(depth)+"Number of estimators="+str(stump))
        confusionMatrixCalculation(y_pred_ens_boost,Ytest)

print("Confusion matrix for Bagging- SK learn Implementation")
#Scikit learn Bagging(Random Forest)
for depth in [3,5]:
    DT= DecisionTreeClassifier(criterion="entropy",max_depth=depth)
    for n in [10,20]:
        
        
        classifier= BaggingClassifier(base_estimator=DT,n_estimators=n)
        classifier.fit(Xtrn,ytrn)
        y_pred=classifier.predict(Xtest)
        print("max_depth="+str(depth)+"Number of estimators="+str(n))
        confusionMatrixCalculation(y_pred,Ytest)
        
        
        
print("Confusion matrix for Adaboost classifier -SKlearn Implementation")

for depth in [1,2]:
    DT=DecisionTreeClassifier(criterion="entropy",max_depth=depth)
    for n in [20,40]:
        Classifier=AdaBoostClassifier(base_estimator=DT,n_estimators=n)
        classifier.fit(Xtrn,ytrn)
        y_pred=classifier.predict(Xtest)
        print("max_depth="+str(depth)+"Number of estimators="+str(n))
        confusionMatrixCalculation(y_pred,Ytest)
        
 






       
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
